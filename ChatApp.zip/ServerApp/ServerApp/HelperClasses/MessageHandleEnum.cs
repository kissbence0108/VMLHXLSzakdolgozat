﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServerApp.HelperClasses
{
    public enum MessageHandleEnum
    {
        LOGIN = 0,
        REGISTER = 1,
        GETMESSAGEHISTORY = 2,
        SENDMESSAGE = 3,
        SENDGRAPHS = 4
    }
}
