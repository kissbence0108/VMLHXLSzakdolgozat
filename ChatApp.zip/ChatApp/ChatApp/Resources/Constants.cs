﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.Resources
{
    public static class Constants
    {
        public static string Username = "";
        public static Guid UserUniqueIdentifier;
        public const char EndOfTransmissionSeparator = (char)004;
        public const char Separator = (char)007;
    }
}
