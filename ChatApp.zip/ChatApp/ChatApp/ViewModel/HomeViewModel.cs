﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.ViewModel
{
    public class HomeViewModel : BaseViewModel
    {
        public HomeViewModel()
        {

        }
    }
}
