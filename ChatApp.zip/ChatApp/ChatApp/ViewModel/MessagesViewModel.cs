﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace ChatApp.ViewModel
{
    public class MessagesViewModel : BaseViewModel
    {



    }
}
