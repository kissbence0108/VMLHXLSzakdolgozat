﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.ViewModel
{
    public class GraphsViewModel : BaseViewModel
    {
        public GraphsViewModel()
        {

        }
    }
}
