﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.HelperClasses
{
    public enum MessageHandleEnum
    {
        LOGIN = 0,
        REGISTER = 1,
        GETMESSAGEHISTORY = 2,
        SENDMESSAGE = 3
    }
}
